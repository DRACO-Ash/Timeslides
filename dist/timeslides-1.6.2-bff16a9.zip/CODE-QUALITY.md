# Code quality: the findings, and what now stops them

Bluestaq Limited · Timeslides

Every rule in this document is a finding the App Store quality gate actually
raised against this project, or the direct generalisation of one. Each cost an
upload, a pipeline run and a round trip to discover. They are written down here
so the reasoning survives, and enforced in code so the next one does not need
discovering at all.

## Why this exists

The gate is SonarQube and it runs in the pipeline, which means it can only tell
you about a problem **after** an upload. Six separate rounds of this project
went: upload, wait, read one finding, fix it, upload again. That is a poor use
of a pipeline and a worse use of an afternoon.

The pattern in those findings is the useful part. `ruff.toml` had covered
Python from the start and says in its own header that it cannot see the CSS or
the JavaScript. **Every gate finding after that file was written landed in
exactly that blind spot.** The gap was not knowledge, it was that nothing ran.

## The three layers, and which one is the guarantee

| Layer | Covers | Runs where | Status |
|---|---|---|---|
| `ruff.toml` | Python | local, `ruff check .` | pre-flight |
| `eslint.config.mjs` | JavaScript, deeply | local, `npx eslint .` | pre-flight |
| `tests/test_code_standards.py` | CSS, this application's own rules, a JavaScript backstop | **everywhere, including the platform's test stage** | the guarantee |

The third layer is pure standard library on purpose. The pipeline's test stage
installs `requirements.txt` and runs `pytest`, nothing else, so a check that
needs a tool installed is a check that will not run there. Anything that must
not regress belongs in that file.

A rule earns a place only if it is mechanically checkable with close to no
false positives. **A check that cries wolf gets switched off, and then it
protects nothing.** Two rules in that file were rewritten during this work
because the first version flagged its own explanatory comment.

## The register

### JavaScript

| Finding | Rule | Enforced by |
|---|---|---|
| "Prefer using an optional chain expression" (twice) | `x && x.y` is `x?.y` | eslint local rule, `find_redundant_guards` |
| "Handle this exception or don't catch it at all" | no empty catch, no unread catch binding | `no-empty`, `no-unused-vars`, `find_empty_catches`, `find_unread_catch_bindings` |
| "The empty object is useless" | no empty literal spread or merged | `prefer-object-spread`, `find_object_assign` |
| Bare `parseInt` | use the `Number` namespace | `no-restricted-globals`, `find_bare_number_globals` |
| `Object.assign` where a spread belongs | use `{...a, ...b}` | `prefer-object-spread`, `find_object_assign` |
| — | no unary-plus coercion; `Number(x)` says what it does | `no-implicit-coercion`, `find_unary_plus_coercions` |
| — | no `var` | `no-var`, `find_var_declarations` |

**The optional-chain rule is the one to read carefully.** It applies to the
redundant form only, where the guard and the access are the same thing. It does
**not** apply to `sel && sel.value !== st.ref`: rewritten as `sel?.value !== st.ref`,
a null `sel` yields `undefined`, the comparison is then true, and the body runs
on the null. `report.js` contains one of those and it is correct as written. A
first attempt at this rule used an esquery selector, which cannot compare two
fields of a node and so flagged `g && window.Plotly`, where the identifiers are
unrelated. It is now a local ESLint rule that compares the two sides.

### CSS

| Finding | Rule | Enforced by |
|---|---|---|
| Duplicate selector | one top-level rule per selector | `find_duplicate_selectors` |
| — | every `!important` carries a comment saying why | `find_unexplained_important` |

`!important` is not banned. Beating an inline style that JavaScript sets, or
honouring a reduced-motion preference whatever else the sheet says, are both
right answers. The rule is that the author has to be able to say which, so a
comment above it has to.

A rule inside `@media` is a different context and is how an override is meant
to be written, so the duplicate check is deliberately top-level only.

### Python

| Finding | Rule | Enforced by |
|---|---|---|
| "Avoid binding the application to all network interfaces" | the host is configuration, in one place, with the reason recorded | `test_the_listen_address_is_configuration_rather_than_a_literal` |
| "Change this code to not construct the path from user-controlled data" | `STORAGE_MOUNT_PATH` validated at the boundary | `_storage_path`, `tests/test_config.py` |
| "This regex is vulnerable to exponential backtracking" | no repeat inside a repeat | `find_nested_quantifiers` |
| `dict()` constructor | use a literal | ruff `C408` |
| Multi-call `pytest.raises` | one call per block | ruff `PT012` family, review |
| Cognitive complexity over 15 | — | ruff `C90`, `max-complexity = 15` |
| Naming, unused arguments, FastAPI `Annotated` | — | ruff `N`, `ARG`, `B` |
| — | no `except` that only passes; `contextlib.suppress` says so | `find_except_that_only_passes` |

### Rules specific to this application

These are not general style. Each is something that was true of Timeslides,
cost a release to learn, and could not have been caught by a general linter.

| What happened | Rule | Enforced by |
|---|---|---|
| Report writes and group writes had separate implementations; the S3 fix landed in one and every render died in the other | every filesystem write goes through `timeslides/storage.py` | `tests/test_nonposix_e2e.py::test_only_the_storage_module_writes_to_the_filesystem` |
| `&middot;` appeared on screen verbatim in a tooltip | no named HTML entity in a Plotly hovertemplate; it decodes only the basic ones | `test_no_named_html_entity_in_a_plotly_hovertemplate` |
| The data-quality band was given the shell's `.err` and `.note`; the report does not load `shell.css` | every class used in a page exists in a stylesheet that page loads | `test_every_class_the_report_uses_exists_in_the_stylesheet_it_loads` |

### The container image

The code-quality gate is not the only gate. The container image policy scans
the built image and is a separate failure mode with a separate register.

| Finding | Rule | Enforced by |
|---|---|---|
| 7 critical, 62 high, mostly in packages the app never calls | the image carries only what the application needs, computed with `ldd` | `tests/test_rootfs_script.py`, and the build's own chroot verification |
| Criticals with an upstream fix the base image predates | the build applies the distribution's security updates | `test_the_build_applies_the_distribution_security_updates` |
| Interpreter CVEs fixed only in a newer minor | the base tag is pinned to a patch version at or above the fixed-in versions | `test_the_base_image_is_pinned_to_a_patch_version` |
| `SUID or SGID found set on file /var/mail` | `harden.sh` strips directories as well as files | `tests/test_harden.py` |

The distinction that matters: a finding with an upstream fix is cleared by
upgrading, and a finding without one can only be cleared by the package not
being in the image. The first shaped the `apt-get upgrade`; the second shaped
the whole minimal-rootfs approach, including removing stdlib extension modules
so the libraries behind them need not ship.

| A scan that sees no packages because the database was dropped | declare the packages that really ship, in `status.d` | `test_the_image_declares_its_packages_to_the_scanner` |

The distinction that matters most here is not a rule about code at all.
**Minimal is not the same as invisible.** Removing the Debian userland removes
the package database with it, and a scanner that cannot find one reports no
operating-system packages: a clean result that means "could not see" rather
than "nothing to see", which is the same fail-open defect as a test that passes
when it could not verify. Fourteen Debian libraries genuinely remain, so the
nine packages that own them are declared to the scanner on purpose.

**A minimal rootfs missing one library builds cleanly and dies on its first
request**, which is worse than a failing scan. So the build chroots into what
it assembled and imports the whole application, runs the physics, and asserts
the removed pieces are genuinely removed.

**Reading a build script is not building it.** Running the script alone found
two defects: the library closure copying into the rootfs it was building, and
pip surviving in the virtualenv. Building the image then found three more, none
of them visible on the page: the interpreter symlink chain that left the entry
point dangling (exit 127 on every start), a `|| true` that swallowed a failed
dependency install and produced an empty virtualenv behind a green build, and
a `dpkg -S` diversion line parsed as a package name. The general rule: a build
step is not verified until it has been run, and `|| true` on a chain rather
than on one command is how a failure becomes a green build.

## The rule about the rules

**A check that reads a file whole will match the comment explaining the check.**
This has now happened three times: the `!important` rule flagged its own
justification, the hovertemplate rule flagged the comment warning against
entities, and a Dockerfile rule flagged the comment describing the line it
forbids. Look at code, not at prose: parse it, or strip the comments first.

**A linter that reports on files that are not yours is a linter people stop
running.** `npx eslint .` with only a `files` pattern and no `ignores` still
walks the whole tree: it reported six errors from the JavaScript bundled inside
the virtualenv's Playwright driver, all of them inline `eslint-disable`
comments naming `@typescript-eslint` rules this config does not load. None of
it is ours and none of it is in the upload. The config now ignores `.venv`,
`node_modules`, `dist` and `reference`, and a test asserts that it does.

**A report the gate cannot resolve reads as zero, not as "no data".** The gate
reported `Line coverage: 0.0%` against a suite measured at 100 per cent, and
the pipeline's own advice was to write more tests. Nothing was wrong with the
tests. `source = timeslides` in `.coveragerc` made coverage.py root the report
at the package's **absolute path on the test runner**, so the scanner resolved
no file and counted every analysed line as uncovered. The generalisation:
anything handed from one stage to another has to be checked in the shape the
receiving stage will read it, not the shape that looks right where it was
made. `tests/test_coverage_report.py` now generates a report and asserts the
paths, and both assertions were confirmed to fail against the old
configuration.

**Two places configuring the same thing will disagree.** `--cov=timeslides` in
`pytest.ini` silently overrode `source` in `.coveragerc`, so the local run and
the pipeline run produced differently shaped reports from the same repository.
The command line now passes a bare `--cov` and `.coveragerc` decides, with a
test pinning that.

**A test may only assert what is true of the code, not of the tree it happens
to run in.** `test_the_two_coverage_exclusion_lists_agree` read
`sonar-project.properties` and failed the pipeline with `FileNotFoundError`,
because the App Store's test stage runs against the unpacked upload and that
file is not in it. Every assertion the test made was true of the repository.
Where a file is legitimately absent in one environment, the check skips with a
reason that says so, and a companion check in a git work tree fails if the file
is actually missing from the repository, so the skip cannot swallow a deletion.

**A probe that decides whether to skip must not be able to fail.** A `skipif`
decorator is evaluated at import, so an exception in it is not one test
failing: pytest reports a collection error and abandons the whole run. A helper
that shelled out to `git` raised `FileNotFoundError` in the pipeline, whose job
container has `.git` but no git binary, and 684 passing tests never executed.

**A helper copied is a helper that will diverge, and the copy nobody is looking
at is the one that breaks.** The correct implementation of that probe already
existed in `tests/conftest.py`, with a docstring describing this exact hazard
and an `except OSError`. A second copy was written beside it without the guard.
There is now one, and `test_there_is_only_one_git_probe` parses the test tree
and fails if a second appears.

**Reproduce the environment; do not remember it.** Three pipeline failures in a
row were environment differences that passed locally. `docker/appstore-sim.sh`
runs the suite the way the platform does -- unpacked tree, no `.git`, no
`sonar-project.properties`, no git binary -- and is in the verification loop.
It was itself verified by reverting the defect and confirming it goes red.

**An artefact handed to another tool must be unambiguous, not merely correct.**
The coverage report was correct: right numbers, relative paths, every file
present. It also carried an empty `<source>` element ahead of the real one, and
a consumer that takes the first root resolves every file to a path that does
not exist. Correct-but-ambiguous reads downstream as wrong, and in this case it
read as nought per cent, which is indistinguishable from having no tests. When
a format allows two readings, emit the one reading.

**A hedge must be labelled as a hedge.** Writing the report to the path the
scanner searches by default is a guess about configuration we cannot see. It is
in the code with the word hypothesis attached and the cost of being wrong
stated, so nobody later reads it as something that was verified.

**When reasoning has been wrong twice, stop reasoning and measure.** Three
rounds of plausible explanations for a 0.0% coverage gate produced three wrong
fixes and cost four uploads. The fourth round ran a real SonarQube against the
repository in three configurations and read the answer off the API in ten
minutes. `docker/sonar-probe.sh` keeps that experiment repeatable. The tell was
available earlier and went unexamined: the arithmetic said an imported report
would score about 73 per cent, so exactly 0.0 could only mean no report was
read at all.

**A test that passes on a clean repository is exactly what a broken detector
also does.** Every detector in `tests/test_code_standards.py` is therefore a
named function, shown both the offender it was written for and the lookalike it
must leave alone. A further test asserts that no detector exists without such a
pair, because a detector nobody calls is a rule nobody enforces.

That principle is the same one behind the browser suite skipping loudly rather
than passing silently when no Chromium is present, and behind the non-POSIX
end-to-end suite running a real server rather than patching a module. Mapping
"could not verify" onto "passed" is the defect that hides every other one.

## Running them

```bash
# Python
.venv/bin/ruff check .

# JavaScript, if eslint is available. The bare "." is safe: the config
# ignores .venv, node_modules, dist and reference.
npx eslint .

# The guarantee, and everything else
.venv/bin/python -m pytest tests/test_code_standards.py
```

All three are part of the verification loop in `AUDIT.md`, which is what runs
before an upload.
